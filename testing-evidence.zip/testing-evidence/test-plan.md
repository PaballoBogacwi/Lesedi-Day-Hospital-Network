# Test Plan \& Results – Milestone 2



|#|Test|Where / how|Expected|Actual|Result|Screenshot|
|-|-|-|-|-|-|-|
|T1|Staff PC gets DHCP|Staff PC > IP Configuration|192.168.12.x (.10-.62), GW .1, DNS .98|192.168.12.x (.10-.62), GW .1, DNS .98|PASS|`T01\_staff\_dhcp.png`|
|T2|Management PC gets DHCP|Mgmt PC > IP Configuration|192.168.12.x (.70-.94), GW .65|192.168.12.x (.70-.94), GW .65|PASS|`T02\_mgmt\_dhcp.png`|
|T3|Staff -> own gateway|Staff PC: `ping 192.168.12.1`|Success|Success|PASS|`T03\_staff\_gw\_ping.png`|
|T4|Staff -> internal web server|Staff PC browser: `http://192.168.12.98`|Hospital page loads|Hospital page loads|PASS|`T04\_staff\_web\_ok.png`|
|T5|Mgmt -> internal web server|Mgmt PC browser: `http://192.168.12.98`|Hospital page loads|Hospital page loads|PASS|`T05\_mgmt\_web\_ok.png`|
|T6|Mgmt -> internet|Mgmt PC browser: `http://198.51.100.10`|External page loads|External page loads|PASS|`T06\_mgmt\_internet\_ok.png`|
|T7|Staff -> internet (blocked)|Staff PC: `ping 198.51.100.10`|Fails (destination unreachable)|Fails (destination unreachable)|PASS|`T07\_staff\_internet\_blocked.png`|
|T8|Staff -> internet web (blocked)|Staff PC browser: `http://198.51.100.10`|Page does not load|Page does not load|PASS|`T08\_staff\_web\_blocked.png`|
|T9|Staff -> Management (blocked)|Staff PC: `ping <mgmt PC IP>`|Fails|Fails|PASS|`T09\_staff\_to\_mgmt\_blocked.png`|
|T10|VLANs|SW1: `show vlan brief`|VLAN 10/20/30 with correct ports|VLAN 10/20/30 with correct ports|PASS|`T10\_show\_vlan.png`|
|T11|Interfaces|R1: `show ip interface brief`|G0/0.10/.20/.30 and G0/1 up/up|G0/0.10/.20/.30 and G0/1 up/up|PASS|`T11\_show\_ip\_int\_brief.png`|
|T12|Routing|R1: `show ip route`|Connected subnets + default route via 203.0.113.1|Connected subnets + default route via 203.0.113.1|PASS|`T12\_show\_ip\_route.png`|
|T13|NAT|R1: `show ip nat translations` (after T6)|Entries for Mgmt PC only|Entries for Mgmt PC only|PASS|`T13\_show\_nat.png`|
|T14|ACL hits|R1: `show access-lists` (after T4, T7-T9)|Matches on permit and deny lines|Password can not be inputed and thus fails and command cannot be received|FAIL|`T14\_show\_acl.png`|
|T15|Web server status|Web server > Services > HTTP|HTTP On, custom index.html|HTTP On, custom index.html|PASS|`T15\_web\_server\_http.png`|
|T16|DNS resolution (Staff)|Staff PC > Command Prompt: `nslookup portal.lesedihospital.co.za`|Returns 192.168.12.98|Returns 192.168.12.98|PASS|`T16\_staff\_nslookup.png`|
|T17|Web by name (Staff)|Staff PC browser: `http://portal.lesedihospital.co.za`|Hospital page loads|Hospital page loads|PASS|`T17\_staff\_web\_by\_name.png`|
|T18|Internet by name (Mgmt)|Mgmt PC browser: `http://www.testinternet.com`|External page loads|External page loads|PASS|`T18\_mgmt\_internet\_by\_name.png`|

* 

